<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>UpdateDbus</name>
    <message>
        <location filename="../updatedbus.cpp" line="39"/>
        <location filename="../updatedbus.cpp" line="41"/>
        <source>mount failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../updatedbus.cpp" line="40"/>
        <source>mount failed,please mount the source by yourself.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
