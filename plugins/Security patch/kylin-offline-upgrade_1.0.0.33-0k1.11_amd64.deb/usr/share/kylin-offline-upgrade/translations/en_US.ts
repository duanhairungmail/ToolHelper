<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_AU">
<context>
    <name>Mainwindow</name>
    <message>
        <source>离线升级</source>
        <translation type="vanished">Offline Upgrade</translation>
    </message>
    <message>
        <source>麒麟系统离线升级工具</source>
        <translation type="vanished">KylinOS Offline Upgrade Tool</translation>
    </message>
    <message>
        <source>选择离线源</source>
        <translation type="vanished">Choose squash</translation>
    </message>
    <message>
        <source>升级前请校准系统时间，避免升级出现异常</source>
        <translation type="vanished">Please calibrate the system time before upgrading.</translation>
    </message>
    <message>
        <source>退出应用</source>
        <translation type="vanished">exit</translation>
    </message>
    <message>
        <source>挂载失败</source>
        <translation type="vanished">Mount failed.</translation>
    </message>
    <message>
        <source>确定</source>
        <translation type="vanished">OK</translation>
    </message>
    <message>
        <source>升级失败</source>
        <translation type="vanished">Upgrade failed.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="24"/>
        <source>Offline Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="55"/>
        <source>KylinOS Offline Upgrade Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="59"/>
        <location filename="../mainwindow.cpp" line="67"/>
        <location filename="../mainwindow.cpp" line="168"/>
        <source>Choose squash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="69"/>
        <source>upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="85"/>
        <source>Please calibrate the system time before upgrading.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="89"/>
        <source>Please view the update results in the update history after upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="92"/>
        <location filename="../mainwindow.cpp" line="100"/>
        <source>exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>quickmount</name>
    <message>
        <location filename="../quickmount.cpp" line="154"/>
        <source>mount failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="155"/>
        <source>mount failed,please mount the source by yourself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="145"/>
        <source>package and offline source do not match，please download the latest offline upgrade tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="141"/>
        <source>install error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="148"/>
        <source>system and offline source do not match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="160"/>
        <location filename="../quickmount.cpp" line="161"/>
        <source>install success</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
