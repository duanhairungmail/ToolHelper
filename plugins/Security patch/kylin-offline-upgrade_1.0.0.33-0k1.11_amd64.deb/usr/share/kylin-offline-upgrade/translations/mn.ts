<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="mn">
<context>
    <name>AppUpdateWid</name>
    <message>
        <source>Cancel failed,Being installed</source>
        <translatorcomment>正在安装，无法取消</translatorcomment>
        <translation type="vanished">正在安装，无法取消</translation>
    </message>
    <message>
        <source>Being installed</source>
        <translation type="vanished">正在安装更新</translation>
    </message>
    <message>
        <source>Download succeeded!</source>
        <translation type="vanished">下载成功！</translation>
    </message>
    <message>
        <source>Update succeeded , It is recommended that you restart later!</source>
        <translation type="vanished">更新成功，建议稍后重启！</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="vanished">版本：</translation>
    </message>
    <message>
        <source>Download finished,it is recommended that you restart later to use the new version.</source>
        <translation type="vanished">更新下载已完成，重启使用新版本。</translation>
    </message>
    <message>
        <source>reboot</source>
        <translation type="vanished">重启</translation>
    </message>
    <message>
        <source>Update succeeded , It is recommended that you log out later and log in again!</source>
        <translation type="vanished">更新成功，建议稍后注销后重新登录！</translation>
    </message>
    <message>
        <source>Update succeeded!</source>
        <translation type="vanished">更新成功！</translation>
    </message>
    <message>
        <source>Update has been canceled!</source>
        <translation type="vanished">本次更新已取消！</translation>
    </message>
    <message>
        <source>Update failed!</source>
        <translation type="vanished">更新异常！</translation>
    </message>
    <message>
        <source>Failure reason:</source>
        <translation type="vanished">失败原因：</translation>
    </message>
    <message>
        <source>Network exception, unable to check for updates!</source>
        <translation type="vanished">网络异常，检查更新异常！</translation>
    </message>
    <message>
        <source>No room, upgrade failed.</source>
        <translation type="vanished">磁盘空间不足，请清理磁盘后进行升级更新。</translation>
    </message>
    <message>
        <source>Battery level is below 50%,and upgrade failed.</source>
        <translation type="vanished">电池电量低于50%，无法升级。</translation>
    </message>
    <message>
        <source>Update failed! </source>
        <translation type="vanished">更新异常！</translation>
    </message>
    <message>
        <source>Error Code: </source>
        <translation type="vanished">错误码：</translation>
    </message>
    <message>
        <source>There are unresolved dependency conflicts in this update，Please select update all</source>
        <translation type="vanished">本次更新存在无法解决的依赖，请选择全部更新</translation>
    </message>
    <message>
        <source>Prompt information</source>
        <translation type="vanished">提示信息</translation>
    </message>
    <message>
        <source>Update ALL</source>
        <translation type="vanished">全部更新</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <source>No Content.</source>
        <translation type="vanished">应用累积更新</translation>
    </message>
    <message>
        <source>There are </source>
        <translation type="vanished">本次更新存在依赖冲突，将卸载</translation>
    </message>
    <message>
        <source> packages going to be removed,Please confirm whether to accept!</source>
        <translation type="vanished">个软件包以完成本次更新。</translation>
    </message>
    <message>
        <source>Cumulative updates</source>
        <translation type="vanished">应用累积更新</translation>
    </message>
    <message>
        <source>packages are going to be removed,Please confirm whether to accept!</source>
        <translation type="vanished">个软件包将被卸载，请确认是否接受！</translation>
    </message>
    <message>
        <source>version:</source>
        <translation type="vanished">版本：</translation>
    </message>
    <message>
        <source>Reboot failed!</source>
        <translation type="vanished">重启失败！</translation>
    </message>
    <message>
        <source>The update stopped because of low battery.</source>
        <translation type="vanished">电池电量较低，系统更新已终止。</translation>
    </message>
    <message>
        <source>The system update requires that the battery power is not less than 50%</source>
        <translation type="vanished">系统更新需要电池电量不低于50%时进行。</translation>
    </message>
    <message>
        <source>pkg will be uninstall!</source>
        <translation type="vanished">个软件包将被卸载！</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">更新</translation>
    </message>
    <message>
        <source>details</source>
        <translation type="vanished">详情</translation>
    </message>
    <message>
        <source>Update log</source>
        <translation type="vanished">更新日志</translation>
    </message>
    <message>
        <source>Newest:</source>
        <translation type="vanished">最新：</translation>
    </message>
    <message>
        <source>Download size:</source>
        <translation type="vanished">下载大小：</translation>
    </message>
    <message>
        <source>Install size:</source>
        <translation type="vanished">安装大小：</translation>
    </message>
    <message>
        <source>Current version:</source>
        <translation type="vanished">当前版本：</translation>
    </message>
    <message>
        <source>back</source>
        <translation type="vanished">收起</translation>
    </message>
    <message>
        <source>The battery is below 50% and the update cannot be downloaded</source>
        <translation type="vanished">电池电量低于 50%，无法下载更新</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">确定</translation>
    </message>
    <message>
        <source>A single update will not automatically backup the system, if you want to backup, please click Update All.</source>
        <translation type="vanished">单个更新不会自动备份系统，如需备份，请点击全部更新。</translation>
    </message>
    <message>
        <source>Do not backup, continue to update</source>
        <translation type="vanished">不备份，继续更新</translation>
    </message>
    <message>
        <source>This time will no longer prompt</source>
        <translation type="vanished">本次更新不再提示</translation>
    </message>
    <message>
        <source>Ready to update</source>
        <translatorcomment>准备更新</translatorcomment>
        <translation type="vanished">准备更新</translation>
    </message>
    <message>
        <source>downloaded</source>
        <translatorcomment>已下载</translatorcomment>
        <translation type="vanished">已下载</translation>
    </message>
    <message>
        <source>Ready to install</source>
        <translation type="vanished">准备安装</translation>
    </message>
    <message>
        <source>downloading</source>
        <translation type="vanished">下载中</translation>
    </message>
    <message>
        <source>calculating</source>
        <translatorcomment>计算中</translatorcomment>
        <translation type="vanished">计算中</translation>
    </message>
    <message>
        <source>No content.</source>
        <translation type="vanished">应用累积更新</translation>
    </message>
</context>
<context>
    <name>DateTimeUtils</name>
    <message>
        <source>No information!</source>
        <translation type="vanished">尚未更新</translation>
    </message>
</context>
<context>
    <name>HistoryUpdateListWig</name>
    <message>
        <source>Success</source>
        <translation type="vanished">更新成功</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation type="vanished">更新失败</translation>
    </message>
</context>
<context>
    <name>Mainwindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="24"/>
        <source>Offline Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="55"/>
        <source>KylinOS Offline Upgrade Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="59"/>
        <location filename="../mainwindow.cpp" line="67"/>
        <location filename="../mainwindow.cpp" line="168"/>
        <source>Choose squash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="69"/>
        <source>upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="85"/>
        <source>Please calibrate the system time before upgrading.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="89"/>
        <source>Please view the update results in the update history after upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="92"/>
        <location filename="../mainwindow.cpp" line="100"/>
        <source>exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">确定</translation>
    </message>
    <message>
        <source>Mount failed.</source>
        <translation type="vanished">挂在失败。</translation>
    </message>
    <message>
        <source>Upgrade failed.</source>
        <translation type="vanished">升级失败。</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>system upgrade new backup</source>
        <translation type="vanished">系统升级新建备份</translation>
    </message>
    <message>
        <source>system upgrade increment backup</source>
        <translation type="vanished">系统升级增量备份</translation>
    </message>
</context>
<context>
    <name>SetWidget</name>
    <message>
        <source>Advanced Option</source>
        <translation type="vanished">高级选项</translation>
    </message>
    <message>
        <source>Server address settings</source>
        <translation type="vanished">服务器地址设置</translation>
    </message>
    <message>
        <source>If there are internal services, you can change the server address.</source>
        <translation type="vanished">如果想使用内部服务，可以更换服务器地址</translation>
    </message>
    <message>
        <source>Protocal</source>
        <translation type="vanished">协议</translation>
    </message>
    <message>
        <source>close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>If internal services, change the server address.</source>
        <translation type="vanished">如果想使用内部服务，可以更换服务器地址</translation>
    </message>
    <message>
        <source>Port  ID </source>
        <translation type="vanished">端口</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="vanished">地址</translation>
    </message>
    <message>
        <source>reset</source>
        <translation type="vanished">恢复默认</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">确定</translation>
    </message>
    <message>
        <source>Modification failed!</source>
        <translation type="vanished">修改失败！</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation type="vanished">提示</translation>
    </message>
</context>
<context>
    <name>TabWid</name>
    <message>
        <source>Check Update</source>
        <translation type="vanished">检查更新</translation>
    </message>
    <message>
        <source>initializing</source>
        <translation type="vanished">初始化中</translation>
    </message>
    <message>
        <source>UpdateAll</source>
        <translation type="vanished">全部更新</translation>
    </message>
    <message>
        <source>Your system is the latest!</source>
        <translation type="vanished">您的系统已是最新！</translation>
    </message>
    <message>
        <source>No Information!</source>
        <translation type="vanished">系统未更新</translation>
    </message>
    <message>
        <source>Last refresh:</source>
        <translation type="vanished">检查时间：</translation>
    </message>
    <message>
        <source>Downloading and installing updates...</source>
        <translation type="vanished">正在下载并安装更新...</translation>
    </message>
    <message>
        <source>Update now</source>
        <translation type="vanished">立即更新</translation>
    </message>
    <message>
        <source>Cancel update</source>
        <translation type="vanished">取消更新</translation>
    </message>
    <message>
        <source>Being updated...</source>
        <translation type="vanished">正在更新...</translation>
    </message>
    <message>
        <source>Updatable app detected on your system!</source>
        <translation type="vanished">检测到系统有更新的应用。</translation>
    </message>
    <message>
        <source>The backup restore partition could not be found. The system will not be backed up in this update!</source>
        <translation type="vanished">未能找到备份还原分区，本次更新不会备份系统！</translation>
    </message>
    <message>
        <source>Kylin backup restore tool is doing other operations, please update later.</source>
        <translation type="vanished">麒麟备份还原工具正在进行其他操作，请稍后更新。</translation>
    </message>
    <message>
        <source>The source manager configuration file is abnormal, the system temporarily unable to update!</source>
        <translation type="vanished">源管理器配置文件异常，暂时无法更新！</translation>
    </message>
    <message>
        <source>Backup already, no need to backup again.</source>
        <translation type="vanished">已备份，无需再次备份。</translation>
    </message>
    <message>
        <source>Start backup,getting progress</source>
        <translation type="vanished">开始备份，正在获取进度</translation>
    </message>
    <message>
        <source>Kylin backup restore tool does not exist, this update will not backup the system!</source>
        <translation type="vanished">麒麟备份还原工具无法找到UUID，本次更新不会备份系统！</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">取消</translation>
    </message>
    <message>
        <source>Calculated</source>
        <translation type="vanished">计算完成</translation>
    </message>
    <message>
        <source>There are unresolved dependency conflicts in this update，Please contact the administrator!</source>
        <translation type="vanished">本次更新存在无法解决的依赖问题，请联系管理员！</translation>
    </message>
    <message>
        <source>Prompt information</source>
        <translation type="vanished">提示信息</translation>
    </message>
    <message>
        <source>Your system is the latest:</source>
        <translation type="vanished">您的系统已是最新：</translation>
    </message>
    <message>
        <source>Sure</source>
        <translation type="vanished">好的</translation>
    </message>
    <message>
        <source>In the download</source>
        <translation type="vanished">下载中</translation>
    </message>
    <message>
        <source>calculating</source>
        <translatorcomment>计算中</translatorcomment>
        <translation type="vanished">计算中</translation>
    </message>
    <message>
        <source>In the install...</source>
        <translation type="vanished">安装中...</translation>
    </message>
    <message>
        <source>Backup complete.</source>
        <translation type="vanished">备份完成。</translation>
    </message>
    <message>
        <source>System is backing up...</source>
        <translation type="vanished">正在备份系统...</translation>
    </message>
    <message>
        <source>Backup interrupted, stop updating!</source>
        <translation type="vanished">备份过程被中断，停止更新！</translation>
    </message>
    <message>
        <source>Backup finished!</source>
        <translation type="vanished">备份完成！</translation>
    </message>
    <message>
        <source>Kylin backup restore tool exception:</source>
        <translation type="vanished">麒麟备份还原工具异常：</translation>
    </message>
    <message>
        <source>There will be no backup in this update!</source>
        <translation type="vanished">本次更新不会备份系统！</translation>
    </message>
    <message>
        <source>The status of backup completion is abnormal</source>
        <translatorcomment>备份完成状态异常</translatorcomment>
        <translation type="vanished">备份完成状态异常</translation>
    </message>
    <message>
        <source>Getting update list</source>
        <translation type="vanished">正在获取更新列表</translation>
    </message>
    <message>
        <source>Software source update successed: </source>
        <translatorcomment>软件源更新成功： </translatorcomment>
        <translation type="vanished">软件源更新成功： </translation>
    </message>
    <message>
        <source>Software source update failed: </source>
        <translation type="vanished">软件源更新失败： </translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">系统更新</translation>
    </message>
    <message>
        <source>There are unresolved dependency conflicts in this update，Please select Dist-upgrade</source>
        <translatorcomment>本次更新存在无法解决的依赖冲突，请选择全盘更新</translatorcomment>
        <translation type="vanished">本次更新存在无法解决的依赖冲突，请选择全盘更新</translation>
    </message>
    <message>
        <source>Dist-upgrade</source>
        <translatorcomment>全盘更新</translatorcomment>
        <translation type="vanished">全盘更新</translation>
    </message>
    <message>
        <source>The system is downloading the update!</source>
        <translation type="vanished">正在下载更新</translation>
    </message>
    <message>
        <source>Downloading the updates...</source>
        <translation type="vanished">正在下载更新......</translation>
    </message>
    <message>
        <source>Installing the updates...</source>
        <translation type="vanished">正在安装更新......</translation>
    </message>
    <message>
        <source>In the install</source>
        <translation type="vanished">安装中</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation type="vanished">重试</translation>
    </message>
    <message>
        <source>The system is checking update :</source>
        <translation type="vanished">正在检测更新：</translation>
    </message>
    <message>
        <source>Download Limit(Kb/s)</source>
        <translation type="vanished">下载限速(Kb/s)</translation>
    </message>
    <message>
        <source>View history</source>
        <translation type="vanished">更新历史</translation>
    </message>
    <message>
        <source>details</source>
        <translation type="vanished">详情</translation>
    </message>
    <message>
        <source>Update Settings</source>
        <translation type="vanished">更新设置</translation>
        <extra-contents_path>/upgrade/Update Settings</extra-contents_path>
    </message>
    <message>
        <source>Allowed to renewable notice</source>
        <translation type="vanished">有更新应用时通知</translation>
    </message>
    <message>
        <source>Backup current system before updates all</source>
        <translation type="vanished">全部更新前备份系统</translation>
    </message>
    <message>
        <source>Download Limit(KB/s)</source>
        <translation type="vanished">下载限速(KB/s)</translation>
    </message>
    <message>
        <source>It will be avaliable in the next download.</source>
        <translation type="vanished">开启后会在下次下载时进行限速。</translation>
    </message>
    <message>
        <source>Automatically download and install updates</source>
        <translation type="vanished">自动下载和安装更新</translation>
    </message>
    <message>
        <source>After it is turned on, the system will automatically download and install updates when there is an available network and available backup and restore partitions.</source>
        <translation type="vanished">开启后，当有可用网络和可用备份和恢复分区时，系统会自动下载和安装更新。</translation>
    </message>
    <message>
        <source>Upgrade during poweroff</source>
        <translation type="vanished">关机检测更新</translation>
    </message>
    <message>
        <source>Download Limit(kB/s)</source>
        <translation type="vanished">下载限速(kB/s)</translation>
    </message>
    <message>
        <source>The system will automatically updates when there is an available network and backup.</source>
        <translation type="vanished">网络可用时，若存在备份，系统会自动下载并安装更新</translation>
    </message>
    <message>
        <source>Ready to install</source>
        <translation type="vanished">准备安装</translation>
    </message>
    <message>
        <source>Last Checked:</source>
        <translation type="vanished">检查时间：</translation>
    </message>
    <message>
        <source>No information!</source>
        <translation type="vanished">尚未更新</translation>
    </message>
    <message>
        <source>Error Code:</source>
        <translation type="vanished">错误码：</translation>
    </message>
    <message>
        <source>Download Limit</source>
        <translation type="vanished">下载限速</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="vanished">高级选项</translation>
    </message>
    <message>
        <source>Dependency conflict exists in this update,need to be completely repaired!</source>
        <translation type="vanished">本次更新存在包依赖冲突，需要全盘修复以完成更新！</translation>
    </message>
    <message>
        <source>There are </source>
        <translation type="vanished">本次更新存在依赖冲突，将卸载</translation>
    </message>
    <message>
        <source> packages going to be removed,Please confirm whether to accept!</source>
        <translation type="vanished">个软件包以完成本次更新。</translation>
    </message>
    <message>
        <source>packages are going to be removed,Please confirm whether to accept!</source>
        <translation type="vanished">个软件包将被卸载，请确认是否接受！</translation>
    </message>
    <message>
        <source>trying to reconnect </source>
        <translation type="vanished">重新尝试连接 </translation>
    </message>
    <message>
        <source> times</source>
        <translation type="vanished">次数</translation>
    </message>
    <message>
        <source>back</source>
        <translation type="vanished">收起</translation>
    </message>
    <message>
        <source>Auto-Update is backing up......</source>
        <translatorcomment>自动更新进程正在备份中......</translatorcomment>
        <translation type="vanished">自动更新进程正在备份中......</translation>
    </message>
    <message>
        <source>The updater is NOT start</source>
        <translation type="vanished">后台更新服务未启动，建议重启计算机！</translation>
    </message>
    <message>
        <source>The progress is updating...</source>
        <translation type="vanished">正在检查更新...</translation>
    </message>
    <message>
        <source>The progress is installing...</source>
        <translation type="vanished">正在下载并安装更新...</translation>
    </message>
    <message>
        <source>The updater is busy！</source>
        <translation type="vanished">其他应用正在安装软件包，请稍后再试</translation>
    </message>
    <message>
        <source>Updating the software source</source>
        <translation type="vanished">正在更新软件源</translation>
    </message>
    <message>
        <source>The battery is below 50% and the update cannot be downloaded</source>
        <translation type="vanished">电池电量低于 50%，无法下载更新</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">确定</translation>
    </message>
    <message>
        <source>Please back up the system before all updates to avoid unnecessary losses</source>
        <translation type="vanished">全部更新前请先备份系统，以免造成不必要的损失！</translation>
    </message>
    <message>
        <source>Only Update</source>
        <translation type="vanished">直接更新</translation>
    </message>
    <message>
        <source>Back And Update</source>
        <translation type="vanished">备份并更新</translation>
    </message>
    <message>
        <source>update has been canceled!</source>
        <translation type="vanished">本次更新已取消！</translation>
    </message>
    <message>
        <source>This update has been completed！</source>
        <translatorcomment>本次更新已完成！</translatorcomment>
        <translation type="vanished">本次更新已完成！</translation>
    </message>
    <message>
        <source>Keeping update</source>
        <translation type="vanished">继续更新</translation>
    </message>
    <message>
        <source>It is recommended to back up the system before all updates to avoid unnecessary losses!</source>
        <translation type="vanished">全部更新前建议备份系统，以免造成不必要的损失！</translation>
    </message>
    <message>
        <source>Insufficient disk space to download updates!</source>
        <translation type="vanished">磁盘空间不足，无法下载更新！</translation>
    </message>
    <message>
        <source>supposed</source>
        <translation type="vanished">预计占用</translation>
    </message>
    <message>
        <source>s</source>
        <translation type="vanished">秒</translation>
    </message>
    <message>
        <source>min</source>
        <translation type="vanished">分钟</translation>
    </message>
    <message>
        <source>h</source>
        <translation type="vanished">小时</translation>
    </message>
    <message>
        <source>Network exception, unable to check for updates!</source>
        <translation type="vanished">网络异常，检查更新异常！</translation>
    </message>
    <message>
        <source>No room, upgrade failed.</source>
        <translation type="vanished">磁盘空间不足，请清理磁盘后进行升级更新。</translation>
    </message>
    <message>
        <source>Checking update failed! </source>
        <translation type="vanished">检查更新异常！</translation>
    </message>
    <message>
        <source>Error Code: </source>
        <translation type="vanished">错误码：</translation>
    </message>
    <message>
        <source>Automatically updates</source>
        <translation type="vanished">自动更新</translation>
    </message>
    <message>
        <source>Rollback to previous version</source>
        <translation type="vanished">回退到上一个版本</translation>
    </message>
    <message>
        <source>start</source>
        <translation type="vanished">开始</translation>
    </message>
    <message>
        <source>Upgrade</source>
        <translation type="vanished">更新</translation>
    </message>
    <message>
        <source>Advanced Option</source>
        <translation type="vanished">高级选项</translation>
    </message>
    <message>
        <source>The update stopped because of low battery.</source>
        <translation type="vanished">电池电量较低，系统更新已终止！</translation>
    </message>
    <message>
        <source>The system update requires that the battery power is not less than 50%</source>
        <translation type="vanished">系统更新需要电池电量不低于50%时进行。</translation>
    </message>
    <message>
        <source>Part of the update failed!</source>
        <translation type="vanished">更新异常！</translation>
    </message>
    <message>
        <source>Failure reason:</source>
        <translatorcomment>失败原因：</translatorcomment>
        <translation type="vanished">失败原因：</translation>
    </message>
    <message>
        <source>Finish the download!</source>
        <translation type="vanished">完成下载！</translation>
    </message>
    <message>
        <source>The system has download the update!</source>
        <translation type="vanished">系统完成更新内容下载</translation>
    </message>
    <message>
        <source>It&apos;s need to reboot to make the install avaliable</source>
        <translation type="vanished">更新下载已完成，是否安装更新。</translation>
    </message>
    <message>
        <source>Reboot notification</source>
        <translation type="vanished">重启提示</translation>
    </message>
    <message>
        <source>Reboot rightnow</source>
        <translation type="vanished">重启并安装</translation>
    </message>
    <message>
        <source>Later</source>
        <translation type="vanished">稍后安装</translation>
    </message>
    <message>
        <source>Part of the update success!</source>
        <translation type="vanished">部分软件包更新成功！</translation>
    </message>
    <message>
        <source>All the update has been downloaded.</source>
        <translation type="vanished">所有的更新内容已经被下载</translation>
    </message>
    <message>
        <source>An important update is in progress, please wait.</source>
        <translation type="vanished">正在进行一项重要更新，请等待。</translation>
    </message>
    <message>
        <source>plase clean up your disk or expand the backup space</source>
        <translation type="vanished">请清理磁盘空间或扩大备份分区</translation>
    </message>
    <message>
        <source>insufficient backup space</source>
        <translation type="vanished">备份空间不足</translation>
    </message>
    <message>
        <source>backup failed</source>
        <translation type="vanished">备份异常</translation>
    </message>
    <message>
        <source>Failed to write configuration file, this update will not back up the system!</source>
        <translation type="vanished">写入配置文件失败，本次更新不会备份系统！</translation>
    </message>
    <message>
        <source>Insufficient backup space, this update will not backup your system!</source>
        <translation type="vanished">备份空间不足，本次更新不会备份系统！</translation>
    </message>
    <message>
        <source>Kylin backup restore tool could not find the UUID, this update will not backup the system!</source>
        <translation type="vanished">麒麟备份还原工具无法找到UUID，本次更新不会备份系统！</translation>
    </message>
    <message>
        <source>The backup restore partition is abnormal. You may not have a backup restore partition.For more details,see /var/log/backup.log</source>
        <translation type="vanished">备份还原分区异常，您可能没有备份还原分区。更多详细信息，可以参看/var/log/backup.log</translation>
    </message>
    <message>
        <source>Calculating Capacity...</source>
        <translation type="vanished">计算系统空间大小...</translation>
    </message>
    <message>
        <source>The system backup partition is not detected. Do you want to continue updating?</source>
        <translation type="vanished">未检测到系统备份还原分区，是否继续更新？</translation>
    </message>
    <message>
        <source>Calculating</source>
        <translation type="vanished">计算中</translation>
    </message>
    <message>
        <source>The system is updating...</source>
        <translation type="vanished">正在准备更新...</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation type="vanished">重启</translation>
    </message>
    <message>
        <source>The system has download the update，and you are suggested to reboot to use the new version.</source>
        <translation type="vanished">已下载最新版本，重启系统后使用新版本。</translation>
    </message>
    <message>
        <source>reboot rightnow</source>
        <translation type="vanished">立即重启</translation>
    </message>
    <message>
        <source>Reboot failed!</source>
        <translation type="vanished">重启失败！</translation>
    </message>
    <message>
        <source>Update failed! </source>
        <translation type="vanished">更新异常！</translation>
    </message>
    <message>
        <source>No room to backup,upgrade failed.</source>
        <translation type="vanished">磁盘空间不足，更新升级异常。</translation>
    </message>
    <message>
        <source>Battery level is below 50%,and upgrade failed.</source>
        <translation type="vanished">电池电量低于50%，无法升级。</translation>
    </message>
    <message>
        <source>preparing to backup</source>
        <translation type="vanished">准备备份</translation>
    </message>
    <message>
        <source>backup start success</source>
        <translation type="vanished">备份开始</translation>
    </message>
    <message>
        <source>Auto-Update progress is installing new file：</source>
        <translatorcomment>系统自动更新功能正在安装新文件：</translatorcomment>
        <translation type="vanished">系统自动更新功能正在安装新文件：</translation>
    </message>
    <message>
        <source>Auto-Update progress finished!</source>
        <translatorcomment>系统自动更新完成！</translatorcomment>
        <translation type="vanished">系统自动更新完成！</translation>
    </message>
    <message>
        <source>Auto-Update progress fail in backup!</source>
        <translatorcomment>自动更新安装时备份失败！</translatorcomment>
        <translation type="vanished">自动更新安装时备份失败！</translation>
    </message>
    <message>
        <source>Failed in updating because of broken environment.</source>
        <translation type="vanished">环境破损未修复，更新失败</translation>
    </message>
    <message>
        <source>It&apos;s fixing up the environment...</source>
        <translation type="vanished">正在修复更新环境......</translation>
    </message>
</context>
<context>
    <name>UpdateDbus</name>
    <message>
        <source>System-Upgrade</source>
        <translation type="vanished">系统更新</translation>
    </message>
    <message>
        <source>ukui-control-center-update</source>
        <translation type="vanished">设置-更新提示</translation>
    </message>
</context>
<context>
    <name>UpdateLog</name>
    <message>
        <source>Update log</source>
        <translation type="vanished">更新日志</translation>
    </message>
</context>
<context>
    <name>UpdateSource</name>
    <message>
        <source>Connection failed, please reconnect!</source>
        <translation type="vanished">连接失败，请重新连接！</translation>
    </message>
</context>
<context>
    <name>Upgrade</name>
    <message>
        <source>Upgrade</source>
        <translation type="vanished">更新</translation>
    </message>
    <message>
        <source>View history</source>
        <translation type="vanished">查看更新历史</translation>
        <extra-contents_path>/Upgrade/View history</extra-contents_path>
    </message>
    <message>
        <source>Update Settings</source>
        <translation type="vanished">更新设置</translation>
        <extra-contents_path>/Upgrade/Update Settings</extra-contents_path>
    </message>
    <message>
        <source>Allowed to renewable notice</source>
        <translation type="vanished">有更新应用时通知</translation>
        <extra-contents_path>/Upgrade/Allowed to renewable notice</extra-contents_path>
    </message>
    <message>
        <source>Automatically download and install updates</source>
        <translation type="vanished">自动下载和安装更新</translation>
        <extra-contents_path>/Upgrade/Automatically download and install updates</extra-contents_path>
    </message>
</context>
<context>
    <name>dependencyfixdialog</name>
    <message>
        <source>details</source>
        <translation type="vanished">详情</translation>
    </message>
    <message>
        <source>show details</source>
        <translation type="vanished">了解详情</translation>
    </message>
    <message>
        <source>uninstall and update</source>
        <translation type="vanished">卸载并更新</translation>
    </message>
    <message>
        <source>uninstall</source>
        <translation type="vanished">移除</translation>
    </message>
    <message>
        <source>cancel</source>
        <translation type="vanished">取消</translation>
    </message>
</context>
<context>
    <name>fixbrokeninstalldialog</name>
    <message>
        <source>We need to fix up the environment!</source>
        <translation type="vanished">需要修复更新环境</translation>
    </message>
    <message>
        <source>There will be uninstall some packages to complete the update!</source>
        <translation type="vanished">将卸载部分软件包以完成更新！</translation>
    </message>
    <message>
        <source>The following packages will be uninstalled:</source>
        <translation type="vanished">下列软件包将被卸载：</translation>
    </message>
    <message>
        <source>PKG Details</source>
        <translation type="vanished">软件包详情</translation>
    </message>
    <message>
        <source>details</source>
        <translation type="vanished">详情</translation>
    </message>
    <message>
        <source>Keep</source>
        <translation type="vanished">拒绝</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="vanished">移除</translation>
    </message>
    <message>
        <source>Attention on update</source>
        <translation type="vanished">更新提示</translation>
    </message>
    <message>
        <source>back</source>
        <translation type="vanished">收起</translation>
    </message>
</context>
<context>
    <name>fixupdetaillist</name>
    <message>
        <source>No content.</source>
        <translation type="vanished">暂无详情</translation>
    </message>
    <message>
        <source>Update Details</source>
        <translation type="vanished">更新详情</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">更新</translation>
    </message>
</context>
<context>
    <name>m_updatelog</name>
    <message>
        <source>No content.</source>
        <translation type="vanished">暂无内容.</translation>
    </message>
    <message>
        <source>no content</source>
        <translation type="vanished">暂无内容</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">关闭</translation>
    </message>
    <message>
        <source>Update Details</source>
        <translation type="vanished">更新详情</translation>
    </message>
    <message>
        <source>No Contents</source>
        <translation type="vanished">暂无内容</translation>
    </message>
    <message>
        <source>Search content</source>
        <translation type="vanished">搜索内容</translation>
    </message>
    <message>
        <source>History Log</source>
        <translation type="vanished">历史更新</translation>
    </message>
</context>
<context>
    <name>quickmount</name>
    <message>
        <location filename="../quickmount.cpp" line="141"/>
        <source>install error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="154"/>
        <source>mount failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="155"/>
        <source>mount failed,please mount the source by yourself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="160"/>
        <location filename="../quickmount.cpp" line="161"/>
        <source>install success</source>
        <translation>ᠤᠭᠰᠠᠷᠠᠪᠠ</translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="145"/>
        <source>package and offline source do not match，please download the latest offline upgrade tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source> package and offline source do not match</source>
        <translation type="vanished">工具和离线源版本不匹配</translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="148"/>
        <source>system and offline source do not match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>mount success</source>
        <translation type="vanished">挂载成功</translation>
    </message>
</context>
<context>
    <name>updatedeleteprompt</name>
    <message>
        <source>Dependency conflict exists in this update!</source>
        <translation type="vanished">本次更新存在依赖冲突！</translation>
    </message>
    <message>
        <source>There will be uninstall some packages to complete the update!</source>
        <translation type="vanished">将卸载部分软件包以完成更新！</translation>
    </message>
    <message>
        <source>The following packages will be uninstalled:</source>
        <translation type="vanished">下列软件包将被卸载：</translation>
    </message>
    <message>
        <source>PKG Details</source>
        <translation type="vanished">软件包详情</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">更新</translation>
    </message>
    <message>
        <source>details</source>
        <translation type="vanished">详情</translation>
    </message>
    <message>
        <source>Keep</source>
        <translation type="vanished">拒绝</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="vanished">接受</translation>
    </message>
    <message>
        <source>Update Prompt</source>
        <translation type="vanished">更新提示</translation>
    </message>
    <message>
        <source>back</source>
        <translation type="vanished">收起</translation>
    </message>
</context>
</TS>
