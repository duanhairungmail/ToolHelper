<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Mainwindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="24"/>
        <source>Offline Upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="55"/>
        <source>KylinOS Offline Upgrade Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="59"/>
        <location filename="../mainwindow.cpp" line="67"/>
        <location filename="../mainwindow.cpp" line="168"/>
        <source>Choose squash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="69"/>
        <source>upgrade</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="85"/>
        <source>Please calibrate the system time before upgrading.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="89"/>
        <source>Please view the update results in the update history after upgrade.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="92"/>
        <location filename="../mainwindow.cpp" line="100"/>
        <source>exit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>quickmount</name>
    <message>
        <location filename="../quickmount.cpp" line="154"/>
        <source>mount failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="155"/>
        <source>mount failed,please mount the source by yourself.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="145"/>
        <source>package and offline source do not match，please download the latest offline upgrade tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="141"/>
        <source>install error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="148"/>
        <source>system and offline source do not match</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="160"/>
        <location filename="../quickmount.cpp" line="161"/>
        <source>install success</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
