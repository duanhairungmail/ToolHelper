<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="bo_CN">
<context>
    <name>AppUpdateWid</name>
    <message>
        <source>Cancel failed,Being installed</source>
        <translatorcomment>取消失败，安装中</translatorcomment>
        <translation type="vanished">ཕམ་ཉེས་བྱུང་ནས་སྒྲིག་སྦྱོར་བྱེད་བཞིན་ཡོད།</translation>
    </message>
    <message>
        <source>Being installed</source>
        <translation type="vanished">སྒྲིག་སྦྱོར་བྱེད་བཞིན་པ།</translation>
    </message>
    <message>
        <source>Download succeeded!</source>
        <translation type="vanished">ཕབ་ལེན་ལེགས་འགྲུབ་བྱུང་བ་རེད།</translation>
    </message>
    <message>
        <source>Update succeeded , It is recommended that you restart later!</source>
        <translation type="vanished">གསར་སྒྱུར་ལེགས་འགྲུབ་བྱུང་སོང་། ཁྱེད་ཀྱིས་རྗེས་སུ་ཡང་བསྐྱར་འགོ་འཛུགས་རྒྱུའི་གྲོས་འགོ་འདོན་རྒྱུ་ཡིན།</translation>
    </message>
    <message>
        <source>Version:</source>
        <translation type="vanished">པར་གཞི་འདི་ལྟ་སྟེ།</translation>
    </message>
    <message>
        <source>Download finished,it is recommended that you restart later to use the new version.</source>
        <translation type="vanished">ཕབ་ལེན་ལེགས་གྲུབ་བྱུང་ནས་གྲོས་འགོ་བསྐྱར་དུ་འདོན་དགོས།</translation>
    </message>
    <message>
        <source>reboot</source>
        <translation type="vanished">བསྐྱར་སློང་།</translation>
    </message>
    <message>
        <source>Update succeeded , It is recommended that you log out later and log in again!</source>
        <translation type="vanished">གསར་སྒྱུར་ལེགས་འགྲུབ་བྱུང་བ་རེད། ཁྱེད་ཀྱིས་རྗེས་སུ་ཐོ་འགོད་བྱས་ནས་ཡང་བསྐྱར་ཐོ་འགོད་བྱ་རྒྱུའི་གྲོས་འགོ་འདོན་རྒྱུ་ཡིན།</translation>
    </message>
    <message>
        <source>Update succeeded!</source>
        <translation type="vanished">གསར་སྒྱུར་ལེགས་འགྲུབ་བྱུང་བ་རེད།</translation>
    </message>
    <message>
        <source>Update has been canceled!</source>
        <translation type="vanished">གསར་སྒྱུར་མེད་པར་བཟོས་ཟིན།</translation>
    </message>
    <message>
        <source>Update failed!</source>
        <translation type="vanished">གསར་སྒྱུར་ལ་ཕམ་ཉེས་བྱུང་བ་རེད།</translation>
    </message>
    <message>
        <source>Failure reason:</source>
        <translation type="vanished">ཕམ་ཉེས་བྱུང་བའི་རྒྱུ་རྐྱེན་ནི།</translation>
    </message>
    <message>
        <source>Network exception, unable to check for updates!</source>
        <translation type="vanished">དྲ་རྒྱའི་དམིགས་བསལ་གྱིས་གནས་ཚུལ་གསར་བར་ཞིབ་བཤེར་བྱེད་ཐབས་བྲལ།</translation>
    </message>
    <message>
        <source>No room, upgrade failed.</source>
        <translation type="vanished">བར་སྟོང་མི་འདང་བ་དང་ཕམ་ཁ་གསར་པ་བྱུང་།</translation>
    </message>
    <message>
        <source>Battery level is below 50%,and upgrade failed.</source>
        <translation type="vanished">གློག་ཚད་དམའ་ཞིང་གསར་སྒྱུར་ཕམ་ཁ་བྱུང་།</translation>
    </message>
    <message>
        <source>Update failed! </source>
        <translation type="vanished">གསར་སྒྱུར་ལ་ཕམ་ཉེས་བྱུང་བ་རེད། </translation>
    </message>
    <message>
        <source>Error Code: </source>
        <translation type="vanished">ནོར་འཁྲུལ་གྱི་ཨང་གྲངས།</translation>
    </message>
    <message>
        <source>There are unresolved dependency conflicts in this update，Please select update all</source>
        <translation type="vanished">གསར་སྒྱུར་འདིའི་ནང་དུ་ཐག་གཅོད་བྱས་མེད་པའི་གཞན་རྟེན་རང་བཞིན་གྱི་འགལ་བ་ཡོད་པས། ཚང་མ་གསར་སྒྱུར་བྱེད་རོགས།</translation>
    </message>
    <message>
        <source>Prompt information</source>
        <translation type="vanished">མགྱོགས་མྱུར་གྱི་ཆ་འཕྲིན།</translation>
    </message>
    <message>
        <source>Update ALL</source>
        <translation type="vanished">ཚང་མ་གསར་སྒྱུར་བྱ་</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">ཕྱིར་འཐེན།</translation>
    </message>
    <message>
        <source>No Content.</source>
        <translation type="vanished">ནང་དོན་གང་ཡང་མེད།</translation>
    </message>
    <message>
        <source>There are </source>
        <translation type="vanished">དེ་རུ་ཡོད་པ་ནི། </translation>
    </message>
    <message>
        <source> packages going to be removed,Please confirm whether to accept!</source>
        <translation type="vanished"> ཐུམ་སྒྲིལ་མེད་པར་བཟོ་རྒྱུ་རེད། ཁྱེད་ཀྱིས་དང་ལེན་བྱེད་མིན་གཏན་འཁེལ་བྱེད་རོགས།</translation>
    </message>
    <message>
        <source>Cumulative updates</source>
        <translation type="vanished">གསོག་འཇོག་གསར་སྒྱུར་བྱེད་དགོས།</translation>
    </message>
    <message>
        <source>packages are going to be removed,Please confirm whether to accept!</source>
        <translation type="vanished">ཐུམ་སྒྲིལ་མེད་པར་བཟོ་རྒྱུ་རེད། ཁྱེད་ཀྱིས་དང་ལེན་བྱེད་མིན་གཏན་འཁེལ་བྱེད་རོགས།</translation>
    </message>
    <message>
        <source>version:</source>
        <translation type="vanished">པར་གཞི་འདི་ལྟ་སྟེ།</translation>
    </message>
    <message>
        <source>The update stopped because of low battery.</source>
        <translation type="vanished">གློག་སྨན་དམའ་བའི་རྐྱེན་གྱིས་གསར་སྒྱུར་བྱེད་མཚམས་བཞག་པ་རེད།</translation>
    </message>
    <message>
        <source>The system update requires that the battery power is not less than 50%</source>
        <translation type="vanished">མ་ལག་གསར་སྒྱུར་བྱེད་པར་གློག་སྨན་གྱི་སྒུལ་ཤུགས་50%ལས་མི་ཉུང་བའི་བླང་བྱ་བཏོན་ཡོད།</translation>
    </message>
    <message>
        <source>pkg will be uninstall!</source>
        <translation type="vanished">个软件包将被卸载！</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">གསར་སྒྱུར།</translation>
    </message>
    <message>
        <source>details</source>
        <translation type="vanished">ཞིབ་ཕྲའི་གནས་ཚུལ།</translation>
    </message>
    <message>
        <source>Update log</source>
        <translation type="vanished">གསར་སྒྱུར་ཉིན་ཐོ།</translation>
    </message>
    <message>
        <source>Newest:</source>
        <translation type="vanished">最新：</translation>
    </message>
    <message>
        <source>Download size:</source>
        <translation type="vanished">ཕབ་ལེན་གྱི་གཞི་ཁྱོན་ནི།</translation>
    </message>
    <message>
        <source>Install size:</source>
        <translation type="vanished">སྒྲིག་སྦྱོར་བྱས་པའི་གཞི་ཁྱོན་ནི།</translation>
    </message>
    <message>
        <source>Current version:</source>
        <translation type="vanished">ད་ལྟའི་པར་གཞི་ནི།</translation>
    </message>
    <message>
        <source>back</source>
        <translation type="vanished">收起</translation>
    </message>
    <message>
        <source>The battery is below 50% and the update cannot be downloaded</source>
        <translation type="vanished">电池电量低于 50%，无法下载更新</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">འགྲིགས།</translation>
    </message>
    <message>
        <source>A single update will not automatically backup the system, if you want to backup, please click Update All.</source>
        <translation type="vanished">གསར་སྒྱུར་རྐྱང་པ་ཞིག་གིས་མ་ལག་རང་འགུལ་གྱིས་རྗེས་གྲབས་བྱེད་མི་སྲིད། གལ་ཏེ་ཁྱོད་ཀྱིས་རྗེས་གྲབས་བྱེད་འདོད་ན་གསར་སྒྱུར་ཚང་མ་མནན་རོགས།</translation>
    </message>
    <message>
        <source>Do not backup, continue to update</source>
        <translation type="vanished">རྗེས་གྲབས་མི་བྱེད་པར་མུ་མཐུད་དུ་གསར་སྒྱུར་བྱེད་དགོས།</translation>
    </message>
    <message>
        <source>This time will no longer prompt</source>
        <translation type="vanished">ཐེངས་འདིར་ཡང་བསྐྱར་སྐུལ་འདེད་བྱེད་མི་ཐུབ།</translation>
    </message>
    <message>
        <source>Ready to update</source>
        <translatorcomment>准备更新</translatorcomment>
        <translation type="vanished">གསར་སྒྱུར་བྱེད་པར་གྲ་སྒྲིག་</translation>
    </message>
    <message>
        <source>downloaded</source>
        <translatorcomment>已下载</translatorcomment>
        <translation type="vanished">ཕབ་ལེན་བྱས་པ།</translation>
    </message>
    <message>
        <source>Ready to install</source>
        <translation type="vanished">准备安装</translation>
    </message>
    <message>
        <source>downloading</source>
        <translation type="vanished">ཕབ་ལེན་བྱེད་པ།</translation>
    </message>
    <message>
        <source>calculating</source>
        <translatorcomment>计算中</translatorcomment>
        <translation type="vanished">རྩིས་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>No content.</source>
        <translation type="vanished">ནང་དོན་གང་ཡང་མེད།</translation>
    </message>
</context>
<context>
    <name>DateTimeUtils</name>
    <message>
        <source>No information!</source>
        <translation type="vanished">དཔྱད་གཞིའི་ཡིག་ཆ་མེད།</translation>
    </message>
</context>
<context>
    <name>HistoryUpdateListWig</name>
    <message>
        <source>Success</source>
        <translation type="vanished">ལེགས་འགྲུབ་བྱུང་བ།</translation>
    </message>
    <message>
        <source>Failed</source>
        <translation type="vanished">ཕམ་ཉེས་བྱུང་བ།</translation>
    </message>
</context>
<context>
    <name>Mainwindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="24"/>
        <source>Offline Upgrade</source>
        <translation>སྐུད་ལམ་དང་བྲལ་ནས་རིམ་པ་སྤར</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="55"/>
        <source>KylinOS Offline Upgrade Tool</source>
        <translation>སྐུད་པ་དང་བྲལ་བའི་རིམ་སྤར་ཡོ་བྱད།</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="59"/>
        <location filename="../mainwindow.cpp" line="67"/>
        <location filename="../mainwindow.cpp" line="168"/>
        <source>Choose squash</source>
        <translation>སྐུད་མེད་ཡིག་ཆ་འདེམས་དགོས།</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="69"/>
        <source>upgrade</source>
        <translation>རིམ་པ་སྤར་བ།</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="85"/>
        <source>Please calibrate the system time before upgrading.</source>
        <translation>རིམ་པ་སྤར་བའི་སྔོན་ལ་སློབ་གྲྭའི་མ་ལག་གི་དུས་ཚོད་གཏན་</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="89"/>
        <source>Please view the update results in the update history after upgrade.</source>
        <translation>རིམ་པ་སྤར་རྗེས་ལོ་རྒྱུས་གསར་སྒྱུར་བྱེད་པར་གཟིགས་རོགས།</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="92"/>
        <location filename="../mainwindow.cpp" line="100"/>
        <source>exit</source>
        <translation>ཕྱིར་འཐེན་བྱ་དགོས།</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="obsolete">འགྲིགས།</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>system upgrade new backup</source>
        <translation type="vanished">མ་ལག་རིམ་སྤར་གྱི་རྗེས་གྲབས་དཔུང་ཁག་</translation>
    </message>
    <message>
        <source>system upgrade increment backup</source>
        <translation type="vanished">མ་ལག་རིམ་སྤར་འཕར་སྣོན་གྱི་རྗེས་གྲབས་དཔུང་ཁག</translation>
    </message>
</context>
<context>
    <name>SetWidget</name>
    <message>
        <source>Close</source>
        <translation type="vanished">སྒོ་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>Advanced Option</source>
        <translation type="vanished">མཐོ་རིམ་འདེམས་ཚན།</translation>
    </message>
    <message>
        <source>Server address settings</source>
        <translation type="vanished">ཞབས་ཞུའི་ཡོ་བྱད་ཀྱི་ས་གནས་འཛུགས་པ།
</translation>
    </message>
    <message>
        <source>If internal services, change the server address.</source>
        <translation type="vanished">གལ་ཏེ་ནང་ཁུལ་གྱི་ཞབས་ཞུ་ཡོད་ན། ཞབས་ཞུའི་ཡོ་བྱད་ཀྱི</translation>
    </message>
    <message>
        <source>Port  ID </source>
        <translation type="vanished">འབོད་ཚིག་བཤད་པ།</translation>
    </message>
    <message>
        <source>Address</source>
        <translation type="vanished">ཤག་གནས།</translation>
    </message>
    <message>
        <source>reset</source>
        <translation type="vanished">བསྐྱར་དུ་བཀོད་སྒྲིག་བྱེད་པ།</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">ཕྱིར་འཐེན།</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">འགྲིགས།</translation>
    </message>
    <message>
        <source>Modification failed!</source>
        <translation type="vanished">ར་སྤྲོད་ཕམ་པ།</translation>
    </message>
    <message>
        <source>Attention</source>
        <translation type="vanished">དོ་སྣང་བྱེད་དགོས།</translation>
    </message>
</context>
<context>
    <name>TabWid</name>
    <message>
        <source>Check Update</source>
        <translation type="vanished">ཞིབ་བཤེར་གསར་སྒྱུར།</translation>
    </message>
    <message>
        <source>initializing</source>
        <translation type="vanished">初始化中</translation>
    </message>
    <message>
        <source>UpdateAll</source>
        <translation type="vanished">གསར་སྒྱུར་བྱེད་པ།</translation>
    </message>
    <message>
        <source>Your system is the latest!</source>
        <translation type="vanished">您的系统已是最新！</translation>
    </message>
    <message>
        <source>No Information!</source>
        <translation type="vanished">དཔྱད་གཞིའི་ཡིག་ཆ་མེད།</translation>
    </message>
    <message>
        <source>Last refresh:</source>
        <translation type="vanished">检查时间：</translation>
    </message>
    <message>
        <source>Downloading and installing updates...</source>
        <translation type="vanished">ཕབ་ལེན་དང་སྒྲིག་སྦྱོར་བྱས་པའི་གནས་ཚུལ་གསར་བ་</translation>
    </message>
    <message>
        <source>Update now</source>
        <translation type="vanished">立即更新</translation>
    </message>
    <message>
        <source>Cancel update</source>
        <translation type="vanished">取消更新</translation>
    </message>
    <message>
        <source>Being updated...</source>
        <translation type="vanished">གསར་སྒྱུར་བྱེད་བཞིན་པའི་སྒང་ཡིན།</translation>
    </message>
    <message>
        <source>Updatable app detected on your system!</source>
        <translation type="vanished">ཁྱེད་ཚོའི་མ་ལག་ནང་དུ་ཞིབ་དཔྱད་ཚད་ལེན་བྱས་པའི་ཉེར་སྤྱོད་གོ་རིམ་གསར་པ་</translation>
    </message>
    <message>
        <source>The backup restore partition could not be found. The system will not be backed up in this update!</source>
        <translation type="vanished">རྗེས་གྲབས་སླར་གསོ་བྱེད་པའི་ཆ་ཤས་རྙེད་མི་ཐུབ། ཐེངས་འདིའི་གསར་སྒྱུར་ཁྲོད་མ་ལག་ལ་རྒྱབ་སྐྱོར་བྱེད་མི་སྲིད།</translation>
    </message>
    <message>
        <source>Kylin backup restore tool is doing other operations, please update later.</source>
        <translation type="vanished">ཅིན་ལིན་གྱི་རྗེས་གྲབས་ཡོ་བྱད་སླར་གསོ་བྱེད་པའི་ཡོ་བྱད་ཀྱིས་ད་དུང་ལས་ཀ་གཞན་དག་བྱེད་བཞིན་ཡོད་པས། རྗེས་སུ</translation>
    </message>
    <message>
        <source>The source manager configuration file is abnormal, the system temporarily unable to update!</source>
        <translation type="vanished">འབྱུང་ཁུངས་ཀྱི་སྤྱི་གཉེར་བའི་བཀོད་སྒྲིག་ཡིག་ཆ་རྒྱུན་ལྡན་མིན་པས་མ་ལག་གནས་སྐབས་སུ་གསར་སྒྱུར་བྱེད་ཐབས་བྲལ་</translation>
    </message>
    <message>
        <source>Backup already, no need to backup again.</source>
        <translation type="vanished">རྗེས་གྲབས་བྱས་ཟིན་པས་སླར་ཡང་རྗེས་གྲབས་བྱེད་དགོས་དོན་མེད།</translation>
    </message>
    <message>
        <source>Start backup,getting progress</source>
        <translation type="vanished">རྗེས་གྲབས་ལས་དོན་སྤེལ་འགོ་བཙུགས་ཏེ་ཡར་རྒྱས་ཡོང</translation>
    </message>
    <message>
        <source>Kylin backup restore tool does not exist, this update will not backup the system!</source>
        <translation type="vanished">ཅིན་ལིན་གྱི་རྗེས་གྲབས་སླར་གསོ་ཡོ་བྱད་མེད་པས། གསར་སྒྱུར་འདིས་མ་ལག་ལ་རྗེས་གྲབས་བྱེད་མི་སྲིད།</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation type="vanished">ཕྱིར་འཐེན།</translation>
    </message>
    <message>
        <source>Calculated</source>
        <translation type="vanished">རྩིས་བརྒྱབ་པ།</translation>
    </message>
    <message>
        <source>There are unresolved dependency conflicts in this update，Please contact the administrator!</source>
        <translation type="vanished">གསར་སྒྱུར་འདིའི་ནང་དུ་ཐག་གཅོད་བྱས་མེད་པའི་གཞན་རྟེན་རང་བཞིན་གྱི་འགལ་བ་ཡོད་པས། དོ་དམ་པར་འབྲེལ་གཏུག་བྱེད་རོགས།</translation>
    </message>
    <message>
        <source>Prompt information</source>
        <translation type="vanished">མགྱོགས་མྱུར་གྱི་ཆ་འཕྲིན།</translation>
    </message>
    <message>
        <source>Your system is the latest:</source>
        <translation type="vanished">ཁྱོད་ཀྱི་མ་ལག་ནི་པར་གཞི་ཆེས་གསར་བ་ཡིན</translation>
    </message>
    <message>
        <source>Sure</source>
        <translation type="vanished">གཏན་འཁེལ་བྱ་དགོས།</translation>
    </message>
    <message>
        <source>In the download</source>
        <translation type="vanished">ཕབ་ལེན་བྱེད་པའི་ཁྲོད།</translation>
    </message>
    <message>
        <source>calculating</source>
        <translatorcomment>计算中</translatorcomment>
        <translation type="vanished">རྩིས་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>In the install...</source>
        <translation type="vanished">安装中...</translation>
    </message>
    <message>
        <source>Backup complete.</source>
        <translation type="vanished">རྗེས་གྲབས་ལས་ཀ་ལེགས་འགྲུབ་བྱུང་བ</translation>
    </message>
    <message>
        <source>System is backing up...</source>
        <translation type="vanished">མ་ལག་གིས་རྒྱབ་སྐྱོར་བྱེད་བཞིན་ཡོད།</translation>
    </message>
    <message>
        <source>Backup interrupted, stop updating!</source>
        <translation type="vanished">རྗེས་གྲབས་བྱེད་མཚམས་བཞག་ནས་གསར་སྒྱུར་བྱེད་མཚམས་འཇོག་དགོས།</translation>
    </message>
    <message>
        <source>Backup finished!</source>
        <translation type="vanished">备份完成！</translation>
    </message>
    <message>
        <source>Kylin backup restore tool exception:</source>
        <translation type="vanished">ཅིན་ལིན་གྱི་རྗེས་གྲབས་ཡོ་བྱད་སླར་གསོ་བྱེད་པའི་ཡོ་བྱད་</translation>
    </message>
    <message>
        <source>There will be no backup in this update!</source>
        <translation type="vanished">གསར་སྒྱུར་འདིའི་ནང་དུ་རྗེས་གྲབས་དཔུང་ཁག་ཡོད་མི་སྲིད།</translation>
    </message>
    <message>
        <source>The status of backup completion is abnormal</source>
        <translatorcomment>备份完成状态异常</translatorcomment>
        <translation type="vanished">རྗེས་གྲབས་ལེགས་འགྲུབ་བྱུང་བའི་གནས་ཚུལ་ནི་རྒྱུན་ལྡན་མིན་པ</translation>
    </message>
    <message>
        <source>Getting update list</source>
        <translation type="vanished">གསར་སྒྱུར་གྱི་མིང་ཐོ་ཐོབ་པ།</translation>
    </message>
    <message>
        <source>Software source update successed: </source>
        <translatorcomment>软件源更新成功： </translatorcomment>
        <translation type="vanished">མཉེན་ཆས་ཀྱི་འབྱུང་ཁུངས་གསར་སྒྱུར་ལེགས་འགྲུབ་བྱུང་བ </translation>
    </message>
    <message>
        <source>Software source update failed: </source>
        <translation type="vanished">མཉེན་ཆས་ཀྱི་འབྱུང་ཁུངས་གསར་སྒྱུར་ལ་ཕམ་ཉེས་བྱུང </translation>
    </message>
    <message>
        <source>Update software source :</source>
        <translation type="vanished">更新软件源进度：</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">གསར་སྒྱུར།</translation>
    </message>
    <message>
        <source>There are unresolved dependency conflicts in this update，Please select Dist-upgrade</source>
        <translatorcomment>本次更新存在无法解决的依赖冲突，请选择全盘更新</translatorcomment>
        <translation type="vanished">ཐེངས་འདིའི་གསར་སྒྱུར་ཁྲོད་དུ་ཐག་གཅོད་བྱས་མེད་པའི་གཞན་རྟེན་རང་བཞིན་གྱི་འགལ་བ་ཡོད་པས། ཁྱེད་ཀྱིས་Dist-upgradeབདམས་རོགས།</translation>
    </message>
    <message>
        <source>Dist-upgrade</source>
        <translatorcomment>全盘更新</translatorcomment>
        <translation type="vanished">རྒྱང་རིང་གི་རིམ་པ་འཕར་བ།</translation>
    </message>
    <message>
        <source>The system is downloading the update!</source>
        <translation type="vanished">མ་ལག་གིས་གསར་སྒྱུར་ཕབ་ལེན་བྱེད་བཞིན་ཡོད།</translation>
    </message>
    <message>
        <source>Downloading the updates...</source>
        <translation type="vanished">གནས་ཚུལ་གསར་པ་ཕབ་ལེན་བྱ་དགོས།</translation>
    </message>
    <message>
        <source>Installing the updates...</source>
        <translation type="vanished">གསར་སྒྱུར་སྒྲིག་སྦྱོར་བྱེད་པ...</translation>
    </message>
    <message>
        <source>In the install</source>
        <translation type="vanished">སྒྲིག་སྦྱོར་བྱེད་པའི་ཁྲོད་</translation>
    </message>
    <message>
        <source>Retry</source>
        <translation type="vanished">བསྐྱར་དུ་ཞིབ་བཤེར་བྱ་དགོས།</translation>
    </message>
    <message>
        <source>Network exception, unable to check for updates!</source>
        <translation type="vanished">དྲ་རྒྱའི་དམིགས་བསལ་གྱིས་གནས་ཚུལ་གསར་བར་ཞིབ་བཤེར་བྱེད་ཐབས་བྲལ།</translation>
    </message>
    <message>
        <source>No room, upgrade failed.</source>
        <translation type="vanished">བར་སྟོང་མི་འདང་བ་དང་ཕམ་ཁ་གསར་པ་བྱུང་།</translation>
    </message>
    <message>
        <source>No room to backup,upgrade failed.</source>
        <translation type="vanished">བར་སྟོང་མི་འདང་བ་དང་ཕམ་ཁ་གསར་པ་ཡོང་བར་བྱ་དགོས།</translation>
    </message>
    <message>
        <source>Battery level is below 50%,and upgrade failed.</source>
        <translation type="vanished">གློག་ཚད་དམའ་ཞིང་གསར་སྒྱུར་ཕམ་ཁ་བྱུང་།</translation>
    </message>
    <message>
        <source>Checking update failed! </source>
        <translation type="vanished">ཞིབ་དཔྱད་ཚད་ལེན་ཕམ་ཉེས་བྱུང་བ་གསར་སྒྱུར་</translation>
    </message>
    <message>
        <source>Error Code: </source>
        <translation type="vanished">ནོར་འཁྲུལ་གྱི་ཨང་གྲངས།</translation>
    </message>
    <message>
        <source>The system is checking update :</source>
        <translation type="vanished">མ་ལག་གིས་གནས་ཚུལ་གསར་བར་ཞིབ་བཤེར་བྱེད་བཞིན་ཡོད།</translation>
    </message>
    <message>
        <source>Rollback to previous version</source>
        <translation type="vanished">པར་གཞི་སྔོན་མ་ཞིག་ལ་ཕྱིར་ལོག་པ།</translation>
    </message>
    <message>
        <source>start</source>
        <translation type="vanished">འགོ་ཚུགས་པ་རེད།</translation>
    </message>
    <message>
        <source>Upgrade</source>
        <translation type="vanished">རིམ་པ་སྤར་བ།</translation>
    </message>
    <message>
        <source>Download Limit(Kb/s)</source>
        <translation type="vanished">下载限速(Kb/s)</translation>
    </message>
    <message>
        <source>View history</source>
        <translation type="vanished">ལོ་རྒྱུས་ལ་ལྟ་ཞིབ་</translation>
    </message>
    <message>
        <source>details</source>
        <translation type="vanished">详情</translation>
    </message>
    <message>
        <source>Update Settings</source>
        <translation type="vanished">གསར་སྒྱུར་སྒྲིག་བཀོད།</translation>
        <extra-contents_path>/upgrade/Update Settings</extra-contents_path>
    </message>
    <message>
        <source>Allowed to renewable notice</source>
        <translation type="vanished">བསྐྱར་སྤྱོད་རུང་བའི་བརྡ་ཐོ་བཏང་ཆོག།</translation>
    </message>
    <message>
        <source>Backup current system before updates all</source>
        <translation type="vanished">ཚང་མ་གསར་སྒྱུར་མ་བྱས་གོང་ལ་ད་ལྟ་སྤྱོད་བཞིན་</translation>
    </message>
    <message>
        <source>Download Limit(KB/s)</source>
        <translation type="vanished">下载限速(KB/s)</translation>
    </message>
    <message>
        <source>It will be avaliable in the next download.</source>
        <translation type="vanished">ཐེངས་རྗེས་མར་ཕབ་ལེན་བྱས་ན་འགན་འཁྲི་འཁུར་དགོས།</translation>
    </message>
    <message>
        <source>Automatically download and install updates</source>
        <translation type="vanished">自动下载和安装更新</translation>
    </message>
    <message>
        <source>After it is turned on, the system will automatically download and install updates when there is an available network and available backup and restore partitions.</source>
        <translation type="vanished">开启后，当有可用网络和可用备份和恢复分区时，系统会自动下载和安装更新。</translation>
    </message>
    <message>
        <source>Upgrade during poweroff</source>
        <translation type="vanished">关机检测更新</translation>
    </message>
    <message>
        <source>Download Limit(kB/s)</source>
        <translation type="vanished">下载限速(kB/s)</translation>
    </message>
    <message>
        <source>The system will automatically updates when there is an available network and backup.</source>
        <translation type="vanished">མ་ལག་འདི་ལ་ད་ཡོད་ཀྱི་དྲ་རྒྱ་དང་རྗེས་གྲབས་ཡོད་པའི་སྐབས་སུ་རང་འགུལ་གྱིས་གསར་སྒྱུར་བྱེད་སྲིད།</translation>
    </message>
    <message>
        <source>Ready to install</source>
        <translation type="vanished">སྒྲིག་སྦྱོར་བྱེད་པར་གྲ་སྒྲིག་</translation>
    </message>
    <message>
        <source>Last Checked:</source>
        <translation type="vanished">མཇུག་མཐར་ཞིབ་བཤེར་བྱས་པ་གཤམ་</translation>
    </message>
    <message>
        <source>Your system is the latest:V10sp1-</source>
        <translation type="vanished">你的系统已是最新版本：V10sp1-</translation>
    </message>
    <message>
        <source>No information!</source>
        <translation type="vanished">དཔྱད་གཞིའི་ཡིག་ཆ་མེད།</translation>
    </message>
    <message>
        <source>Download Limit</source>
        <translation type="vanished">ཕབ་ལེན་གྱི་བཅད་གྲངས།</translation>
    </message>
    <message>
        <source>Advanced</source>
        <translation type="vanished">སྔོན་ཐོན་རང་བཞིན།</translation>
    </message>
    <message>
        <source>Dependency conflict exists in this update,need to be completely repaired!</source>
        <translation type="vanished">གསར་སྒྱུར་འདིའི་ཁྲོད་དུ་གཞན་རྟེན་རང་བཞིན་གྱི་འགལ་བ་ཡོད་པས་རྦད་དེ་ཉམས་གསོ་བྱེད་དགོས།</translation>
    </message>
    <message>
        <source>There are </source>
        <translation type="vanished">དེ་རུ་ཡོད་པ་ནི། </translation>
    </message>
    <message>
        <source> packages going to be removed,Please confirm whether to accept!</source>
        <translation type="vanished"> ཐུམ་སྒྲིལ་མེད་པར་བཟོ་རྒྱུ་རེད། ཁྱེད་ཀྱིས་དང་ལེན་བྱེད་མིན་གཏན་འཁེལ་བྱེད་རོགས།</translation>
    </message>
    <message>
        <source>packages are going to be removed,Please confirm whether to accept!</source>
        <translation type="vanished">ཐུམ་སྒྲིལ་མེད་པར་བཟོ་རྒྱུ་རེད། ཁྱེད་ཀྱིས་དང་ལེན་བྱེད་མིན་གཏན་འཁེལ་བྱེད་རོགས།</translation>
    </message>
    <message>
        <source>trying to reconnect </source>
        <translation type="vanished">ཐབས་བརྒྱ་ཇུས་སྟོང་གིས་འབྲེལ་མཐུད་བྱེད་པ། </translation>
    </message>
    <message>
        <source> times</source>
        <translation type="vanished"> དུས་རབས་</translation>
    </message>
    <message>
        <source>back</source>
        <translation type="vanished">收起</translation>
    </message>
    <message>
        <source>Auto-Update is backing up......</source>
        <translatorcomment>自动更新进程正在备份中......</translatorcomment>
        <translation type="vanished">རང་འགུལ་གྱིས་གསར་སྒྱུར་བྱེད་པར་རྒྱབ་སྐྱོར་བྱེད་བཞིན་ཡོད།</translation>
    </message>
    <message>
        <source>The updater is NOT start</source>
        <translation type="vanished">གསར་སྒྱུར་བྱེད་མཁན་གྱིས་གསར་སྒྱུར་བྱེད་འགོ་ཚུགས་མེད།</translation>
    </message>
    <message>
        <source>The progress is updating...</source>
        <translation type="vanished">འཕེལ་རིམ་གསར་སྒྱུར་བྱེད་བཞིན་ཡོད།</translation>
    </message>
    <message>
        <source>The progress is installing...</source>
        <translation type="vanished">འཕེལ་རིམ་སྒྲིག་སྦྱོར་བྱེད་བཞིན་པའི་སྒང་རེད།</translation>
    </message>
    <message>
        <source>The updater is busy！</source>
        <translation type="vanished">གསར་སྒྱུར་བྱེད་མཁན་དེ་བྲེལ་བ་ཧ་ཅང་ཆེ།</translation>
    </message>
    <message>
        <source>Updating the software source</source>
        <translation type="vanished">མཉེན་ཆས་ཀྱི་འབྱུང་ཁུངས་གསར་སྒྱུར་བྱེད་པ།</translation>
    </message>
    <message>
        <source>The battery is below 50% and the update cannot be downloaded</source>
        <translation type="vanished">电池电量低于 50%，无法下载更新</translation>
    </message>
    <message>
        <source>OK</source>
        <translation type="vanished">འགྲིགས།</translation>
    </message>
    <message>
        <source>Please back up the system before all updates to avoid unnecessary losses</source>
        <translation type="vanished">གསར་སྒྱུར་མ་བྱས་གོང་ལ་མ་ལག་ཕྱིར་འཐེན་བྱས་ནས་དགོས་མེད་ཀྱི་གྱོང་གུན་མི་ཡོང་བ་བྱེད་དགོས།</translation>
    </message>
    <message>
        <source>Only Update</source>
        <translation type="vanished">གསར་སྒྱུར་ཁོ་ན་བྱེད་</translation>
    </message>
    <message>
        <source>Back And Update</source>
        <translation type="vanished">རྒྱབ་ཕྱོགས་དང་གསར་སྒྱུར།</translation>
    </message>
    <message>
        <source>update has been canceled!</source>
        <translation type="vanished">གསར་སྒྱུར་མེད་པར་བཟོས་ཟིན།</translation>
    </message>
    <message>
        <source>This update has been completed！</source>
        <translatorcomment>本次更新已完成！</translatorcomment>
        <translation type="vanished">གསར་སྒྱུར་འདི་ལེགས་འགྲུབ་བྱུང་སོང་།</translation>
    </message>
    <message>
        <source>Your system is the latest:V10</source>
        <translation type="vanished">ཁྱེད་ཚོའི་མ་ལག་ནི་ཆེས་གསར་བ་ཡིན། V10</translation>
    </message>
    <message>
        <source>Keeping update</source>
        <translation type="vanished">གསར་སྒྱུར་རྒྱུན་འཁྱོངས་བྱེད་པ</translation>
    </message>
    <message>
        <source>It is recommended to back up the system before all updates to avoid unnecessary losses!</source>
        <translation type="vanished">གསར་སྒྱུར་མ་བྱས་གོང་ལ་མ་ལག་ལ་རྒྱབ་སྐྱོར་བྱས་ནས་དགོས་མེད་ཀྱི་གྱོང་གུན་མི་ཡོང་བ་བྱ་རྒྱུའི་གྲོས་འགོ་བཏོན་པ་རེད།</translation>
    </message>
    <message>
        <source>Insufficient disk space to download updates!</source>
        <translation type="vanished">ཕབ་ལེན་བྱས་པའི་གསར་སྒྱུར་གྱི་བར་སྟོང་མི་འདང་བ་རེད།</translation>
    </message>
    <message>
        <source>supposed</source>
        <translation type="vanished">ཚོད་དཔག་བྱས་པ་</translation>
    </message>
    <message>
        <source>s</source>
        <translation type="vanished">s</translation>
    </message>
    <message>
        <source>min</source>
        <translation type="vanished">ཟིན་བྲིས་གནད་བསྡུས།</translation>
    </message>
    <message>
        <source>h</source>
        <translation type="vanished">h</translation>
    </message>
    <message>
        <source>Automatically updates</source>
        <translation type="vanished">རང་འགུལ་གྱིས་གསར་སྒྱུར་བྱེད་</translation>
    </message>
    <message>
        <source>Advanced Option</source>
        <translation type="vanished">ཚད་མཐོའི་གདམ་ཁ་</translation>
    </message>
    <message>
        <source>The update stopped because of low battery.</source>
        <translation type="vanished">གློག་སྨན་དམའ་བའི་རྐྱེན་གྱིས་གསར་སྒྱུར་བྱེད་མཚམས་བཞག་པ་རེད།</translation>
    </message>
    <message>
        <source>The system update requires that the battery power is not less than 50%</source>
        <translation type="vanished">མ་ལག་གསར་སྒྱུར་བྱེད་པར་གློག་སྨན་གྱི་སྒུལ་ཤུགས་50%ལས་མི་ཉུང་བའི་བླང་བྱ་བཏོན་ཡོད།</translation>
    </message>
    <message>
        <source>Part of the update failed!</source>
        <translation type="vanished">གསར་སྒྱུར་གྱི་ཆ་ཤས་ཤིག་ལ་ཕམ་ཉེས་བྱུང་བ་རེད།</translation>
    </message>
    <message>
        <source>Failure reason:</source>
        <translatorcomment>失败原因：</translatorcomment>
        <translation type="vanished">ཕམ་ཉེས་བྱུང་བའི་རྒྱུ་རྐྱེན་ནི།</translation>
    </message>
    <message>
        <source>Finish the download!</source>
        <translation type="vanished">ཕབ་ལེན་བྱས་ཚར་སོང་།</translation>
    </message>
    <message>
        <source>The system has download the update!</source>
        <translation type="vanished">མ་ལག་གིས་གསར་སྒྱུར་ཕབ་ལེན་བྱས་ཡོད།</translation>
    </message>
    <message>
        <source>It&apos;s need to reboot to make the install avaliable</source>
        <translation type="vanished">སྒྲིག་སྦྱོར་བྱས་ནས་སྒྲིག་སྦྱོར་བྱས་ན་འགྲིག་གི་རེད།</translation>
    </message>
    <message>
        <source>Reboot notification</source>
        <translation type="vanished">བསྐྱར་དུ་བརྡ་ཐོ་གཏོང་དགོས།</translation>
    </message>
    <message>
        <source>Reboot rightnow</source>
        <translation type="vanished">གཡས་ཕྱོགས་པ་བསྐྱར་དུ་ཐོན་པ།</translation>
    </message>
    <message>
        <source>Later</source>
        <translation type="vanished">རྗེས་སུ།</translation>
    </message>
    <message>
        <source>Part of the update success!</source>
        <translation type="vanished">གསར་སྒྱུར་ལེགས་འགྲུབ་བྱུང་བའི་ཆ་ཤས་ཤིག་རེད།</translation>
    </message>
    <message>
        <source>All the update has been downloaded.</source>
        <translation type="vanished">གསར་སྒྱུར་ཚང་མ་ཕབ་ལེན་བྱས་ཟིན།</translation>
    </message>
    <message>
        <source>An important update is in progress, please wait.</source>
        <translation type="vanished">གལ་འགངས་ཆེ་བའི་གནས་ཚུལ་གསར་བ་ཞིག་ད་ལྟ་སྤེལ་བཞིན་ཡོད།རེ་སྒུག་</translation>
    </message>
    <message>
        <source>plase clean up your disk or expand the backup space</source>
        <translation type="vanished">ཁྱེད་ལ་གཙང་བཤེར་འཁོར་གཞོང་བར་སྟོང་འམ་རྒྱ་བསྐྱེད་རྗེས་གྲབས།འཛུགས་སྐྲུན་ཁག། </translation>
    </message>
    <message>
        <source>insufficient backup space</source>
        <translation type="vanished">གསོག་ཉར་ཁམས་མི་འདང་བ།</translation>
    </message>
    <message>
        <source>backup failed</source>
        <translation type="vanished">གསོག་ཉར་ཕམ་ཁ། </translation>
    </message>
    <message>
        <source>Failed to write configuration file, this update will not back up the system!</source>
        <translation type="vanished">བཀོད་སྒྲིག་ཡིག་ཆ་འབྲི་མ་ཐུབ་ན། གསར་སྒྱུར་འདིས་མ་ལག་ལ་རྒྱབ་སྐྱོར་བྱེད་མི་སྲིད།</translation>
    </message>
    <message>
        <source>Insufficient backup space, this update will not backup your system!</source>
        <translation type="vanished">རྗེས་གྲབས་ཀྱི་བར་སྟོང་མི་འདང་བས། གསར་སྒྱུར་འདིས་ཁྱེད་ཚོའི་མ་ལག་ལ་རྗེས་གྲབས་བྱེད་མི་སྲིད།</translation>
    </message>
    <message>
        <source>Kylin backup restore tool could not find the UUID, this update will not backup the system!</source>
        <translation type="vanished">ཅིན་ལིན་གྱི་རྗེས་གྲབས་ཡོ་བྱད་ཀྱིས་UUIDམ་རྙེད་པས། གསར་སྒྱུར་འདིས་མ་ལག་ལ་རྗེས་གྲབས་བྱེད་མི་ཐུབ།</translation>
    </message>
    <message>
        <source>The backup restore partition is abnormal. You may not have a backup restore partition.For more details,see /var/log/backup.log</source>
        <translation type="vanished">备份还原分区异常，您可能没有备份还原分区。更多详细信息，可以参看/var/log/backup.log</translation>
    </message>
    <message>
        <source>Calculating Capacity...</source>
        <translation type="vanished">ནུས་པ་རྩིས་རྒྱག་པ...</translation>
    </message>
    <message>
        <source>The system backup partition is not detected. Do you want to continue updating?</source>
        <translation type="vanished">未检测到系统备份还原分区，是否继续更新？</translation>
    </message>
    <message>
        <source>Calculating</source>
        <translation type="vanished">རྩིས་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>The system is updating...</source>
        <translation type="vanished">ལམ་ལུགས་གསར་སྒྱུར་བྱེད་བཞིན་ཡོད།</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation type="vanished">བསྐྱར་སློང་།</translation>
    </message>
    <message>
        <source>The system has download the update，and you are suggested to reboot to use the new version.</source>
        <translation type="vanished">མ་ལག་གསར་སྒྱུར་བྱས་ནས་ཕབ་ལེན་བྱས་པ་དང་གྲོས་འགོ་ཡང་བསྐྱར་སྒྲིག་སྦྱོར་བྱ་རྒྱུའི་གྲོས་འགོ</translation>
    </message>
    <message>
        <source>reboot rightnow</source>
        <translation type="vanished">ལམ་སང་བསྐྱར་དུ་སྒོ་འབྱེད་དགོས།</translation>
    </message>
    <message>
        <source>Reboot failed!</source>
        <translation type="vanished">བསྐྱར་སློང་ཕམ་པ།</translation>
    </message>
    <message>
        <source>preparing to backup</source>
        <translation type="vanished">སྐལ་བ་གྲ་སྒྲིག་བྱེད་དགོས།</translation>
    </message>
    <message>
        <source>Update failed! </source>
        <translation type="vanished">གསར་སྒྱུར་ལ་ཕམ་ཉེས་བྱུང་བ་རེད། </translation>
    </message>
    <message>
        <source>backup start success</source>
        <translation type="vanished">སྐལ་ཆ་གྲ་སྒྲིག་བྱེད་འགོ་</translation>
    </message>
    <message>
        <source>Auto-Update progress is installing new file：</source>
        <translatorcomment>系统自动更新功能正在安装新文件：</translatorcomment>
        <translation type="vanished">རང་འགུལ་གྱིས་གསར་སྒྱུར་བྱེད་པའི་འཕེལ་རིམ་ནི་ཡིག་ཆ་གསར་པ་སྒྲིག་སྦྱོར་བྱེད་</translation>
    </message>
    <message>
        <source>Auto-Update progress finished!</source>
        <translatorcomment>系统自动更新完成！</translatorcomment>
        <translation type="vanished">རང་འགུལ་གྱིས་གསར་སྒྱུར་གྱི་འཕེལ་རིམ་ལེགས་འགྲུབ་བྱུང་</translation>
    </message>
    <message>
        <source>Auto-Update progress fail in backup!</source>
        <translatorcomment>自动更新安装时备份失败！</translatorcomment>
        <translation type="vanished">རང་འགུལ་གྱིས་གསར་སྒྱུར་བྱེད་པའི་འཕེལ་རིམ་དེ་རྗེས་གྲབས་ལས་དོན་ལ་ཕམ</translation>
    </message>
    <message>
        <source>Failed in updating because of broken environment.</source>
        <translation type="vanished">ཁོར་ཡུག་གཏོར་བཤིག་བཏང་བའི་རྐྱེན་གྱིས་གསར་སྒྱུར་བྱེད་མ་ཐུབ་པ་རེད།</translation>
    </message>
    <message>
        <source>It&apos;s fixing up the environment...</source>
        <translation type="vanished">དེས་ཁོར་ཡུག་ཞིག་གསོ་བྱེད་བཞིན་ཡོད།</translation>
    </message>
</context>
<context>
    <name>UpdateDbus</name>
    <message>
        <source>System-Upgrade</source>
        <translation type="vanished">མ་ལག་རིམ་སྤར།</translation>
    </message>
    <message>
        <source>ukui-control-center-update</source>
        <translation type="vanished">ukui-control-center-update</translation>
    </message>
</context>
<context>
    <name>UpdateLog</name>
    <message>
        <source>Update log</source>
        <translation type="vanished">གསར་སྒྱུར་ཉིན་ཐོ།</translation>
    </message>
</context>
<context>
    <name>UpdateSource</name>
    <message>
        <source>Connection failed, please reconnect!</source>
        <translation type="vanished">འབྲེལ་མཐུད་བྱེད་མ་ཐུབ་པས་ཡང་བསྐྱར་འབྲེལ་མཐུད་བྱེད་རོགས།</translation>
    </message>
</context>
<context>
    <name>Upgrade</name>
    <message>
        <source>Upgrade</source>
        <translation type="vanished">རིམ་པ་སྤར་བ།</translation>
    </message>
    <message>
        <source>View history</source>
        <translation type="vanished">ལོ་རྒྱུས་ལ་ལྟ་ཞིབ་</translation>
        <extra-contents_path>/Upgrade/View history</extra-contents_path>
    </message>
    <message>
        <source>Update Settings</source>
        <translation type="vanished">གསར་སྒྱུར་སྒྲིག་བཀོད།</translation>
        <extra-contents_path>/Upgrade/Update Settings</extra-contents_path>
    </message>
    <message>
        <source>Allowed to renewable notice</source>
        <translation type="vanished">བསྐྱར་སྤྱོད་རུང་བའི་བརྡ་ཐོ་བཏང་ཆོག།</translation>
        <extra-contents_path>/Upgrade/Allowed to renewable notice</extra-contents_path>
    </message>
    <message>
        <source>Automatically download and install updates</source>
        <translation type="vanished">རང་འགུལ་གྱིས་ཕབ་ལེན་དང་སྒྲིག་སྦྱོར་བྱས་པའི་གནས་</translation>
        <extra-contents_path>/Upgrade/Automatically download and install updates</extra-contents_path>
    </message>
</context>
<context>
    <name>dependencyfixdialog</name>
    <message>
        <source>details</source>
        <translation type="vanished">详情</translation>
    </message>
    <message>
        <source>show details</source>
        <translation type="vanished">ཞིབ་ཕྲའི་གནས་ཚུལ་གསལ་བཤད་</translation>
    </message>
    <message>
        <source>uninstall and update</source>
        <translation type="vanished">སྒྲིག་སྦྱོར་དང་གསར་སྒྱུར་མ་བྱས་པ།</translation>
    </message>
    <message>
        <source>uninstall</source>
        <translation type="vanished">移除</translation>
    </message>
    <message>
        <source>cancel</source>
        <translation type="vanished">ཕྱིར་འཐེན།</translation>
    </message>
</context>
<context>
    <name>fixbrokeninstalldialog</name>
    <message>
        <source>We need to fix up the environment!</source>
        <translation type="vanished">ང་ཚོས་ཁོར་ཡུག་ཞིག་གསོ་བྱེད་དགོས།</translation>
    </message>
    <message>
        <source>There will be uninstall some packages to complete the update!</source>
        <translation type="vanished">དེ་རུ་ཐུམ་སྒྲིལ་ཁ་ཤས་སྒྲིག་སྦྱོར་བྱས་ནས་གསར་སྒྱུར་ལེགས་འགྲུབ་བྱེད་རྒྱུ་རེད།</translation>
    </message>
    <message>
        <source>The following packages will be uninstalled:</source>
        <translation type="vanished">གཤམ་གསལ་གྱི་ཐུམ་སྒྲིལ་དེ་དག་སྒྲིག་སྦྱོར་བྱས་མེད་པ་སྟེ།</translation>
    </message>
    <message>
        <source>PKG Details</source>
        <translation type="vanished">PKGཡི་ཞིབ་ཕྲའི་གནས་ཚུལ།</translation>
    </message>
    <message>
        <source>details</source>
        <translation type="vanished">ཞིབ་ཕྲའི་གནས་ཚུལ།</translation>
    </message>
    <message>
        <source>Keep</source>
        <translation type="vanished">ཉར་ཚགས་ཡག་པོ་</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="vanished">མེད་པར་བཟོ་བ།</translation>
    </message>
    <message>
        <source>Attention on update</source>
        <translation type="vanished">གསར་སྒྱུར་ལ་དོ་སྣང་བྱེད་པ།</translation>
    </message>
    <message>
        <source>back</source>
        <translation type="vanished">རྒྱབ་ཕྱོགས་སུ་ཕྱིར་</translation>
    </message>
</context>
<context>
    <name>fixupdetaillist</name>
    <message>
        <source>No content.</source>
        <translation type="vanished">ནང་དོན་གང་ཡང་མེད།</translation>
    </message>
    <message>
        <source>Update Details</source>
        <translation type="vanished">གནས་ཚུལ་ཞིབ་ཕྲ་གསར་སྒྱུར་བྱ་</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">གསར་སྒྱུར།</translation>
    </message>
</context>
<context>
    <name>m_updatelog</name>
    <message>
        <source>No content.</source>
        <translation type="vanished">ནང་དོན་གང་ཡང་མེད།</translation>
    </message>
    <message>
        <source>no content</source>
        <translation type="vanished">གནས་སྐབས་སུ་ནང་དོན་མེད་པ།</translation>
    </message>
    <message>
        <source>Close</source>
        <translation type="vanished">སྒོ་རྒྱག་པ།</translation>
    </message>
    <message>
        <source>Update Details</source>
        <translation type="vanished">གནས་ཚུལ་ཞིབ་ཕྲ་གསར་སྒྱུར་བྱ་</translation>
    </message>
    <message>
        <source>No Contents</source>
        <translation type="vanished">གནས་སྐབས་མེད་པའི་ནང་དོན། </translation>
    </message>
    <message>
        <source>Search content</source>
        <translation type="vanished">འཚོལ་བཤེར་གྱི་ནང་དོན།</translation>
    </message>
    <message>
        <source>History Log</source>
        <translation type="vanished">ལོ་རྒྱུས་ཀྱི་ཟིན་ཐོ།</translation>
    </message>
</context>
<context>
    <name>quickmount</name>
    <message>
        <location filename="../quickmount.cpp" line="141"/>
        <source>install error</source>
        <translation>སྒྲིག་སྦྱོར་རྒྱུན་ལྡན་མིན་པ།</translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="154"/>
        <source>mount failed</source>
        <translation>བཀལ་ཟིན་པ་ཕམ་ཉེས་བྱུང་</translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="155"/>
        <source>mount failed,please mount the source by yourself.</source>
        <translation>བཀལ་ནས་ཕམ་ཁ་བྱུང་ན་ལག་པ་འགུལ་ནས་བཀལ་ཆོག</translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="160"/>
        <location filename="../quickmount.cpp" line="161"/>
        <source>install success</source>
        <translation>སྒྲིག་སྦྱོར་ལེགས་འགྲུབ་བྱུང་བ།</translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="145"/>
        <source>package and offline source do not match，please download the latest offline upgrade tool</source>
        <translation>ཡོ་བྱད་དང་སྐུད་བྲལ་འབྱུང་ཁུངས་ཀྱི་པར་གཞི་གཉིས་ཆ་མི་འགྲིག་པས་སྐུད་བྲལ་རིམ་སྤར་ཡོ་བྱད་གསར་ཤོས་ཕབ་ལེན་བྱེད་རོགས།</translation>
    </message>
    <message>
        <source> package and offline source do not match</source>
        <translation type="vanished">ཐིག་དང་བྲལ་བའི་ཡོ་བྱད་དང་སྐུད་བྲལ་འབྱུང་ཁུངས་ཀྱི་པར་གཞི་གཉིས་ཆ་མི་མཐུན་པ།</translation>
    </message>
    <message>
        <location filename="../quickmount.cpp" line="148"/>
        <source>system and offline source do not match</source>
        <translation>རྒྱུད་རིམ་ལྡན་པའི་པར་གཞི་དང་སྐུད་པའི་འབྱུང་ཁུངས་དོ་མི་མཉམ་པ།</translation>
    </message>
    <message>
        <source>mount success</source>
        <translation type="vanished">སྦྱར་བ་ལེགས་འགྲུབ་བྱུང་བ།</translation>
    </message>
</context>
<context>
    <name>updatedeleteprompt</name>
    <message>
        <source>Dependency conflict exists in this update!</source>
        <translation type="vanished">本次更新存在依赖冲突！</translation>
    </message>
    <message>
        <source>There will be uninstall some packages to complete the update!</source>
        <translation type="vanished">将卸载部分软件包以完成更新！</translation>
    </message>
    <message>
        <source>The following packages will be uninstalled:</source>
        <translation type="vanished">གཤམ་གསལ་གྱི་ཐུམ་སྒྲིལ་དེ་དག་སྒྲིག་སྦྱོར་བྱས་མེད་པ་སྟེ།</translation>
    </message>
    <message>
        <source>PKG Details</source>
        <translation type="vanished">PKGཡི་ཞིབ་ཕྲའི་གནས་ཚུལ།</translation>
    </message>
    <message>
        <source>Update</source>
        <translation type="vanished">གསར་སྒྱུར།</translation>
    </message>
    <message>
        <source>details</source>
        <translation type="vanished">详情</translation>
    </message>
    <message>
        <source>Keep</source>
        <translation type="vanished">ཉར་ཚགས་ཡག་པོ་</translation>
    </message>
    <message>
        <source>Remove</source>
        <translation type="vanished">མེད་པར་བཟོ་བ།</translation>
    </message>
    <message>
        <source>Update Prompt</source>
        <translation type="vanished">更新提示</translation>
    </message>
    <message>
        <source>back</source>
        <translation type="vanished">收起</translation>
    </message>
</context>
</TS>
