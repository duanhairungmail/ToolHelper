<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>UpdateDbus</name>
    <message>
        <location filename="../updatedbus.cpp" line="39"/>
        <location filename="../updatedbus.cpp" line="41"/>
        <source>mount failed</source>
        <translatorcomment>挂载失败</translatorcomment>
        <translation>挂载失败</translation>
    </message>
    <message>
        <location filename="../updatedbus.cpp" line="40"/>
        <source>mount failed,please mount the source by yourself.</source>
        <translatorcomment>挂载离线源失败，请重新使用离线升级工具挂载离线源。</translatorcomment>
        <translation>挂载离线源失败，请重新使用离线升级工具挂载离线源。</translation>
    </message>
</context>
</TS>
